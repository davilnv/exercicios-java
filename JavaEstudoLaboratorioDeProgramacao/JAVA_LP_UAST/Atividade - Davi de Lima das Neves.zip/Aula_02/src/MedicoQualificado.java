
public class MedicoQualificado extends EquipeMedica{

}
