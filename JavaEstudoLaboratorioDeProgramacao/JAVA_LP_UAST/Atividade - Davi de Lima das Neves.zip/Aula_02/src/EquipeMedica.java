
public class EquipeMedica extends MedicoHospital{

}
