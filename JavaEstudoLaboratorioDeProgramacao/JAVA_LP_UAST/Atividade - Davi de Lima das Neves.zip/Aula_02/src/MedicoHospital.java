
public class MedicoHospital extends Medico{
	public int numeroDoEquipe;
	public int numeroDoPage;
	
	public int getNumeroDoEquipe() {
		return this.numeroDoEquipe;
	}
	public void setNumeroDoEquipe(int numeroDoEquipe) {
		this.numeroDoEquipe = numeroDoEquipe;
	}
	public int getNumeroDoPage() {
		return this.numeroDoPage;
	}
	public void setNumeroDoPage(int numeroDoPage) {
		this.numeroDoPage = numeroDoPage;
	}
}
