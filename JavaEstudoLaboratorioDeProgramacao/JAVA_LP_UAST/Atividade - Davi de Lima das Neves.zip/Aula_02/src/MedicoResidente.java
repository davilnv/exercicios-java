
public class MedicoResidente extends EquipeMedica{

}
