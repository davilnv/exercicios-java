
public class Consultar extends MedicoHospital{

}
