
public class ClinicoGeral extends Medico{
	private String experiencia;
	private String endereco;
	public String getExperiencia() {
		return this.experiencia;
	}
	public void setExperiencia(String experiencia) {
		this.experiencia = experiencia;
	}
	public String getEndereco() {
		return this.endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
}
